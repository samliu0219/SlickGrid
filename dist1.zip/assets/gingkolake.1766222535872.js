var a="assets/gingkolake.1766222535872.png";export{a as l};
