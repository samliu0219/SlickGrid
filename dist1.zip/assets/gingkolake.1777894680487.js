var a="assets/gingkolake.1777894680487.png";export{a as l};
