var a="assets/gingkolake.1768216385888.png";export{a as l};
