var o="assets/logo-mini.1766293365137.svg";export{o as l};
