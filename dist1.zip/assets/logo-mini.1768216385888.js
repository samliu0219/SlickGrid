var o="assets/logo-mini.1768216385888.svg";export{o as l};
