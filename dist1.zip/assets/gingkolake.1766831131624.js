var a="assets/gingkolake.1766831131624.png";export{a as l};
