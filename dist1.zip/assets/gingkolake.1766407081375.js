var a="assets/gingkolake.1766407081375.png";export{a as l};
