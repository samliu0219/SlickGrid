var o="assets/logo-mini.1766188407586.svg";export{o as l};
