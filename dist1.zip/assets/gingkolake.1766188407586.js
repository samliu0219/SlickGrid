var a="assets/gingkolake.1766188407586.png";export{a as l};
