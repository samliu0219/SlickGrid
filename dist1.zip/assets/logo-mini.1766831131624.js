var o="assets/logo-mini.1766831131624.svg";export{o as l};
