var o="assets/logo-mini.1766222535872.svg";export{o as l};
