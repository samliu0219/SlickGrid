var a="assets/gingkolake.1766293365137.png";export{a as l};
