var o="assets/logo-mini.1777894680487.svg";export{o as l};
