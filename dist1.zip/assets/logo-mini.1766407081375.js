var o="assets/logo-mini.1766407081375.svg";export{o as l};
