var o="assets/logo-mini.1762078475220.svg";export{o as l};
