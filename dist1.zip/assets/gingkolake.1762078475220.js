var a="assets/gingkolake.1762078475220.png";export{a as l};
