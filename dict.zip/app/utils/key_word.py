from app.models.sys_user import get_all_user


class _key_word:
    def __init__(self):
        self.key_word = {}
        all_user = get_all_user()
        for u in all_user:
            print('u.user_name={}'.format(u.user_name))
            self.key_word[u.account] = u.user_name

    def get_key_word(self):
        return self.key_word


SingleKeyWord = _key_word()
