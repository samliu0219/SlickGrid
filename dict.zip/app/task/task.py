import json
import logging
from datetime import datetime
from app.models.sys_user import SysUser, user_exits, generate_password, get_max_id
from app.models.sys_user_role import SysUserRole
from app.utils.core import db
from wechatpy.session.redisstorage import RedisStorage
from redis import Redis
from wechatpy.work import WeChatClient

logger = logging.getLogger(__name__)
redis_client = Redis.from_url('redis://127.0.0.1:6379/0')
session_interface = RedisStorage(redis_client, prefix="wechatpy")
# 通訊錄秘鑰ROC-YmgKxTQBtvDKcFOH-9ybuKtbfjVpyUabdCLBBGg
client = WeChatClient(corp_id="wwbb2b7bbc151ab86a", secret="ROC-YmgKxTQBtvDKcFOH-9ybuKtbfjVpyUabdCLBBGg", session=session_interface)


# {'userid': 'LvZeHua', 'name': '吕泽华', 'department': [1], 'position': '',
# 'mobile': '13914495083', 'gender': '1', 'email': '',
# 'avatar': 'http://wework.qpic.cn/bizmail/oZhEknLdUGz34t1bibQQy0BHCwmDdsm8TCopg4kiaHviciaZPnRmlIcIpA/0',
# 'status': 1, 'enable': 1, 'isleader': 0, 'extattr': {'attrs': []}, 'hide_mobile': 0, 'telephone': '',
# 'order': [4096], 'external_profile': {'external_attr': [], 'external_corp_name': ''},
# 'main_department': 1, 'qr_code': 'https://open.work.weixin.qq.com/wwopen/userQRCode?vcode=vccded333aadaa7ccc',
# 'alias': '', 'is_leader_in_dept': [0], 'address': '',
# 'thumb_avatar': 'http://wework.qpic.cn/bizmail/oZhEknLdUGz34t1bibQQy0BHCwmDdsm8TCopg4kiaHviciaZPnRmlIcIpA/100',
# 'direct_leader': [], 'biz_mail': 'lvzehua@njyxh.wecom.work'},
#
def sync_dept_data():
    try:
        return
        # dept = client.department.get(id=1)
        # print('dept={}'.format(dept))
        # print('token={}'.format(client.access_token))
        # region 獲取用戶數據
        try:
            user = client.department.get_users(id=1, status=0, fetch_child=1, simple=False)
        except Exception as e:
            logger.error('獲取用戶數據:'.format(e))
        else:
            # region 獲取用戶表最大的ID
            max_id = get_max_id()[0] + 1
            # endregion
            new_users = []
            new_user_role = []
            for u in user:
                print('userid=>{}'.format(u['userid']))
                re = user_exits(u['userid'])
                pwd = generate_password(u['userid'], u['userid'])
                print('re=>{}'.format(re))
                if re is None:
                    new_users.append(SysUser(id=max_id, created_at=datetime.now(), create_by='批次作業', sex=u['gender'], email=u['email'], status=u['status'], password=pwd, account=u['userid'], work_id=u['userid'], user_name=u['name'], phone=u['mobile'], avatar=u['thumb_avatar']))
                    new_user_role.append(SysUserRole(user_id=max_id, role_id=2))
                    max_id = max_id+1
            db.session.add_all(new_users)
            db.session.commit()
            db.session.add_all(new_user_role)
            db.session.commit()
        # endregion
        print('finn=ok')
    except Exception as e:
        print('e=>{}'.format(e))
    db.session.close()
    print('finish={}'.format('a'))


def my_job():
    print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))


def db_query():
    with db.app.app_context():
        data = db.session.query(SysUser).first()
        print(data)
