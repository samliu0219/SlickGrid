import json
import logging
from flask import Blueprint, request, render_template, session, redirect, url_for
from wechatpy.work import WeChatClient
import functools
from app.utils.core import db
from app.models.sys_user_role import get_roles_by_businessexpress
from wechatpy.session.redisstorage import RedisStorage
from redis import Redis

# region 前置区
bp = Blueprint("work/oath", __name__, url_prefix='/')
logger = logging.getLogger(__name__)
redis_client = Redis.from_url('redis://127.0.0.1:6379/0')
session_interface = RedisStorage(redis_client, prefix="wechatpy")
client = WeChatClient(corp_id="wwbb2b7bbc151ab86a", secret="4cvlKdOyBkGTHKwS-RAMw11SyjaNf5zYnvDyLR9l16w", session=session_interface)


# endregion


def oauth(method):
    @functools.wraps(method)
    def warpper(*args, **kwargs):
        code = request.args.get('code', None)
        url = client.oauth.authorize_url(request.url)
        if code:
            try:
                user_info = client.oauth.get_user_info(code)
            except Exception as e:
                logger.error('e=>{}.{}'.format(e.errmsg, e.errcode))
                # 这里需要处理请求里包含的 code 无效的情况
            else:
                session['user_info'] = user_info
        else:
            return redirect(url)
        return method(*args, **kwargs)

    return warpper


@bp.route('/work/oath', methods=["POST", "GET"])
@oauth
def work_oath():
    #user_info = {'UserId': 'LiuDaCheng', 'DeviceId': 'c2b4be35-6df6-464f-9d7a-3d1380b6399b', 'errcode': 0, 'errmsg': 'ok'}
    user_info = session.get('user_info')

    # region 在数据表中,检查UserID
    if user_info['errcode'] != 0 or user_info['errmsg'] != 'ok':
        return 'error'
    # endregion
    objs_roles = get_roles_by_businessexpress(user_info['UserId'])
    lst_roles = []
    for item in objs_roles:
        print('item={}'.format(item[0]))
        lst_roles.append(item[0])
    if len(lst_roles) < 1:
        logger.info('in error={}'.format(user_info['UserId']))
        return render_template("api/page/businessexpress/error.html")
    elif len(lst_roles) == 1:
        if 'manage' in lst_roles:
            parm_value = {"page": "manage"}
        else:
            print('type={},reporter={}'.format(lst_roles, user_info['UserId']))
            parm_value = {"page": "report", "type": lst_roles, "reporter": user_info['UserId']}
    else:
        parm_value = {"page": "multi", "type": lst_roles, "reporter": user_info['UserId']}
    return render_template("api/page/businessexpress/index.html", parm_value=json.dumps(parm_value))
    # endregion
