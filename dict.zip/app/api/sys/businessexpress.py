import json
import logging
from flask import Blueprint, request
from app.models.business_today import get_last_record, update_last_record, get_total_today, get_sum_today
from app.utils.code import ResponseCode
from app.utils.response import ResMsg
from app.utils.core import db
from app.models.business_accumulate import get_total_week, get_sum_week, get_sum_month, get_total_month, update_accumulate_record
from app.models.business_update_record import get_history_type
from decimal import Decimal
import datetime
from app.models.sys_user import get_name_by_account

import time

# region 前置区
bp = Blueprint("sys/businessexpress/getLastIncomeByType", __name__, url_prefix='/')
logger = logging.getLogger(__name__)
business_dict = {'ticket': '乐园', 'golf': '高尔夫', 'hotel': '酒店', 'sale': '商铺'}
# endregion


# region 定制方法
def parse_income_data(datas, total_income):
    item_data = [
        {"value": 0.00, "name": '乐园', "percentage": '0%'},
        {"value": 0.00, "name": '高尔夫', "percentage": '0%'},
        {"value": 0.00, "name": '酒店', "percentage": '0%'},
        {"value": 0.00, "name": '商铺', "percentage": '0%'}
    ]
    for item in datas:
        key = business_dict[item[0]]
        idx = [x for x in item_data if x['name'] == key]
        item_data.remove(idx[0])
        item_data.append({"value": Decimal(item[1]).quantize(Decimal('0.00')), "name": business_dict[item[0]], "percentage": '{:.2%}'.format(Decimal(item[1]) / Decimal(total_income))})
    return item_data


# endregion

# region 获取当日提交历史数据
@bp.route('/sys/businessexpress/gethistorydata', methods=["POST"])
def get_history_data():
    res = ResMsg()
    obj = request.get_json(force=True)
    _type = obj.get('reporttype', None)
    if _type is None:
        res.update(code=ResponseCode.InvalidParameter)
        return res.data
    list_history = get_history_type(_type)
    tmp = []
    for item in list_history:
        tmp.append({"income": item.income, "update_by": item.update_by, "updated_at": item.updated_at, "update_income": item.update_income.strftime("%Y/%m/%d")})
    res.update(code=ResponseCode.Success, data=tmp)
    db.session.close()
    return res.data
# endregion


# region 获取最后一次上传营收数据
@bp.route('/sys/businessexpress/getlastincomebytype', methods=["POST"])
def get_last_income_type():
    res = ResMsg()
    obj = request.get_json(force=True)
    _type = obj.get('reporttype', None)
    if _type is None:
        res.update(code=ResponseCode.InvalidParameter)
        return res.data
    _data = get_last_record(_type)
    res.update(code=ResponseCode.Success, data={"type": _data.report_type, "income": _data.income, "create_by": get_name_by_account(_data.create_by), "created_at": _data.created_at})
    db.session.close()
    return res.data


# endregion

# region 上传单一种类累积金额
@bp.route('/sys/businessexpress/upIncome', methods=["POST"])
def update_last_income():
    res = ResMsg()
    obj = request.get_json(force=True)
    _reporttype = obj.get('reporttype', None)
    _income = obj.get('income', None)
    _create_by = obj.get('create_by', None)
    _date = obj.get('date', None)
    if _reporttype is None:
        res.update(code=ResponseCode.InvalidParameter)
        return res.data
    if _income is None:
        res.update(code=ResponseCode.InvalidParameter)
        return res.data
    if _create_by is None:
        res.update(code=ResponseCode.InvalidParameter)
        return res.data
    if _date is None:
        res.update(code=ResponseCode.InvalidParameter)
        return res.data
    print('{}--{}'.format(_date,datetime.datetime.now().strftime("%Y/%-m/%-d")))
    if _date == datetime.datetime.now().strftime("%Y/%-m/%-d"):
        recode = update_last_record(_reporttype, _income, _create_by, _date)  # 更新當日數據
    else:
        recode = update_accumulate_record(_reporttype, _income, _create_by, _date)  # 更新历史记录
    if recode == 1:
        _data = get_last_record(_reporttype)
        res.update(code=ResponseCode.Success, data={"type": _data.report_type, "income": _data.income, "create_by": get_name_by_account(_data.create_by), "created_at": _data.created_at})
    else:
        res.update(code=ResponseCode.Fail)
    db.session.close()
    return res.data


# endregion

# region 获取当日周月营收数据
@bp.route('/sys/businessexpress/gettotalday', methods=["GET"])
def get_total_day():
    res = ResMsg()
    all_data = []
    day_data = get_total_today()
    day_income = get_sum_today()
    if day_income is None:
        day_income = 0
    all_data.append({"totalincome": day_income, "option": {"title": {"text": "当日累积营收{}元".format(day_income)}, "series": [{"data": parse_income_data(day_data, day_income)}]}})
    week_data = get_total_week()
    week_income = get_sum_week()
    if week_income is None:
        week_income = 0
    week_income = week_income + day_income
    all_data.append({"totalincome": week_income, "option": {"title": {"text": "当周累积营收{}元".format(week_income)}, "series": [{"data": parse_income_data(week_data, week_income)}]}})
    month_data = get_total_month()
    month_income = get_sum_month()
    if month_income is None:
        month_income = 0
    month_income = month_income  + day_income
    all_data.append({"totalincome": month_income, "option": {"title": {"text": "当周累积营收{}元".format(month_income)}, "series": [{"data": parse_income_data(month_data, month_income)}]}})
    res.update(code=ResponseCode.Success, data=all_data)
    db.session.close()
    return res.data
# endregion
