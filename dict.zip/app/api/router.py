from app.api.api_test import bp as bp_api_test
from app.api.sam_test import bp as bp_sam_test
from app.api.sys.menu import bp as bp_sys_menu
from app.api.sys.login import bp as bp_sys_login
from app.api.work.receive import bp as work_receive
from app.api.work.oath import bp as work_oath
from app.api.sys.businessexpress import bp as businessexpress
router = [
    bp_api_test,  # 接口测试
    bp_sam_test,
    bp_sys_menu,
    bp_sys_login,
    work_receive,
    work_oath,
    businessexpress,
]
