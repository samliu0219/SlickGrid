import logging
from flask import Blueprint, request
from app.utils.core import db
from app.models.sys_role_menu import SysRoleMenu
from app.models.sys_menu import SysMenu
from app.utils.code import ResponseCode
from app.utils.response import ResMsg

bp = Blueprint("sam", __name__, url_prefix='/')

logger = logging.getLogger(__name__)


# -----------------原生蓝图路由---------------#


@bp.route('/sam/logs', methods=["POST"])
def test_logger():
    """
    测试自定义logger
    :return:
    """
    res = ResMsg()
    obj = request.get_json(force=True)
    code = obj.get('code', None)
    refresh_token = request.args.get("refresh_token")
    if not refresh_token:
        res.update(code=ResponseCode.InvalidParameter, msg="refresh_token 无输入")
        return res.data
    logger.info("code {}".format(code))
    logger.info("refresh_token {}".format(refresh_token))
    uu = db.session.query(SysMenu).filter(SysMenu.id == 1).first()
    change_logs = db.session.query(SysMenu.name, SysMenu.created_at, SysRoleMenu.id).join(SysRoleMenu, SysRoleMenu.menu_id == SysMenu.id).filter(SysRoleMenu.role_id == 1).all()
    logger.info("this is info  ===={}".format(len(change_logs)))
    for v in change_logs:
        logger.info("this is info  ===={}".format(v.created_at))
    logger.info("this is debug {}".format(change_logs[0].created_at))
    logger.warning("this is warning")
    logger.error("this is error")
    logger.critical("this is critical")
    return "sam ok"
