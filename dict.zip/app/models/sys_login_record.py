from app.utils.core import db


def add_record(user_id, ip):
    """
    新增登入记录
    :param user_id:
    :param ip:
    :return:
    """
    new_record = SysLoginRecord()
    new_record.user_id = user_id
    new_record.ip = ip
    db.session.add(new_record)
    db.session.commit()


class SysLoginRecord(db.Model):
    """
    角色菜单关系表
    """
    __tablename__ = 'sys_login_record'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # ID
    user_id = db.Column(db.Integer, db.ForeignKey('sys_user.id'))  # 用户ID
    ip = db.Column(db.String(50))  # 用户IP
    created_at = db.Column(db.DateTime)  # 创建时间
