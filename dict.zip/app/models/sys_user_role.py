from app.utils.core import db
from app.models.sys_user import SysUser
from app.models.sys_role import SysRole


def get_roles_by_businessexpress(userid):
    """

    :param userid:
    :return:
    """
    return db.session.query(SysRole.data_scope).join(SysUserRole, SysUserRole.role_id == SysRole.id).filter(SysUser.account == userid, SysRole.role_key == 'businessexpress').all()


def get_roles_by_userid(userid):
    """

    :param userid:
    :return:
    """
    return db.session.query(SysRole.role_key).join(SysUserRole, SysUserRole.role_id == SysRole.id).filter(SysUserRole.user_id == userid).all()


class SysUserRole(db.Model):
    """
    用户和角色关联表
    """
    __tablename__ = 'sys_user_role'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # ID
    role_id = db.Column(db.Integer, db.ForeignKey('sys_role.id'))  # 角色ID
    user_id = db.Column(db.Integer, db.ForeignKey('sys_user.id'))  # 用户ID
