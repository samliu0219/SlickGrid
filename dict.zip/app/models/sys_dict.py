from app.utils.core import db
from app.models.sys_user import SysUser
from app.models.sys_user_dict import SysUserDict


def get_dict_by_userid(user_id):
    """

    :param user_id:
    :return:
    """
    return db.session.query(SysDict.dict_type, SysDict.dict_value_type, SysUser.id, SysUser.user_name).join(SysUserDict.dict_id == SysDict.id).join(SysUser.id == SysUserDict.user_id).filter(SysUser.user_id == user_id).all()


class SysDict(db.Model):
    """
    字典表
    """
    __tablename__ = 'sys_dict'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # ID
    dict_sid = db.Column(db.String(100))
    dict_sort = db.Column(db.String(100))
    dict_label = db.Column(db.String(100))
    dict_type = db.Column(db.String(100))
    dict_number = db.Column(db.String(100))
    dict_value = db.Column(db.String(100))
    dict_value_type = db.Column(db.String(100))
    css_class = db.Column(db.String(100))
    list_class = db.Column(db.String(100))
    is_default = db.Column(db.String(100))
    status = db.Column(db.String(100))
    create_by = db.Column(db.String(50))
    created_at = db.Column(db.DateTime)
    update_by = db.Column(db.String(50))
    updated_at = db.Column(db.DateTime)
    remark = db.Column(db.String(200))
