import logging
from app.utils.core import db
from datetime import datetime

logger = logging.getLogger(__name__)


def add_record(report_type, income, update_by, update_income):
    """
    新增更新记录
    :param user_id:
    :param ip:
    :return:
    """
    new_record = BusinessUpdateRecord()
    new_record.report_type = report_type
    new_record.income = income
    new_record.update_by = update_by
    new_record.updated_at = datetime.now()
    new_record.update_income = datetime.strptime(update_income, "%Y/%m/%d")
    db.session.add(new_record)
    db.session.commit()


def get_history_type(_report_type):
    return db.session.query(BusinessUpdateRecord).filter(BusinessUpdateRecord.report_type == _report_type, BusinessUpdateRecord.updated_at >= datetime.now().strftime("%Y-%m-%d")).order_by(BusinessUpdateRecord.updated_at.desc()).all()


class BusinessUpdateRecord(db.Model):
    """

    """
    __tablename__ = 'business_update_record'
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # ID
    report_type = db.Column(db.String(10))
    income = db.Column(db.Numeric(precision=10, scale=2))
    update_by = db.Column(db.String(50))
    updated_at = db.Column(db.DateTime)
    update_income = db.Column(db.DateTime)
