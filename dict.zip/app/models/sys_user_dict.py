from app.utils.core import db


class SysUserDict(db.Model):
    """
    用戶和字典關聯表
    """
    __tablename__ = 'sys_user_dict'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # ID
    user_id = db.Column(db.Integer, db.ForeignKey('sys_user.id'))  # 用户ID
    dict_id = db.Column(db.Integer, db.ForeignKey('sys_dict.id'))
