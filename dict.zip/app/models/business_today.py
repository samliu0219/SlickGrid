from app.utils.core import db
from sqlalchemy.dialects.mysql import insert
from app.models.business_update_record import add_record
from datetime import datetime
from sqlalchemy.sql import func
import pandas as pd
import logging

logger = logging.getLogger(__name__)


def update_last_record(_type, _income, _create_by, _update_income):
    try:
        data = {"report_type": _type, "income": _income, "create_by": _create_by, "created_at": datetime.now()}
        statement = insert(BusinessToday).values(**data).on_duplicate_key_update(**data)
        db.session.execute(statement)
        # region 記錄更新記錄
        add_record(_type, _income, _create_by, _update_income)
        # endregion
        db.session.commit()
    except Exception as e:
        logger.error('update_last_record.{}'.format(e))
        return 0
    else:
        return 1


def get_last_record(_type):
    return db.session.query(BusinessToday).filter(BusinessToday.report_type == _type).first()


def get_sum_today():
    """
    获取当日全种类全营收总数据
    :return:
    """
    return db.session.query(func.sum(BusinessToday.income).label('total')).scalar()


def get_total_today():
    """
    获取当日全种类营收
    :return:
    """
    df1 = pd.read_sql(db.session.query(BusinessToday.report_type.label('report_type'), BusinessToday.income.label('income')).statement, db.session.bind)
    #return db.session.query(BusinessToday.report_type.label('report_type'), BusinessToday.income.label('income')).all()
    return df1.values.tolist()


class BusinessToday(db.Model):
    """

    """
    __tablename__ = 'business_today'
    report_type = db.Column(db.String(10), primary_key=True)
    income = db.Column(db.Numeric(precision=10, scale=2))
    create_by = db.Column(db.String(50))
    created_at = db.Column(db.DateTime)
