from app.utils.core import db
import datetime
from sqlalchemy.sql import func
from app.models.business_today import BusinessToday
import pandas as pd
from sqlalchemy.dialects.mysql import insert
from app.models.business_update_record import add_record
import logging

logger = logging.getLogger(__name__)


def get_sum_week():
    week = datetime.date.today().isocalendar()[1]
    year = datetime.date.today().isocalendar()[0]
    return db.session.query(func.sum(BusinessAccumulate.income).label('total')).filter(BusinessAccumulate.year == year, BusinessAccumulate.week == week).scalar()


def get_total_week():
    week = datetime.date.today().isocalendar()[1]
    year = datetime.date.today().isocalendar()[0]
    df1 = pd.read_sql(db.session.query(BusinessToday.report_type.label('report_type'), BusinessToday.income.label('income')).statement, db.session.bind)
    df2 = pd.read_sql(db.session.query(BusinessAccumulate.report_type.label('report_type'), func.sum(BusinessAccumulate.income).label('income')).filter(BusinessAccumulate.year == year, BusinessAccumulate.week == week).group_by(BusinessAccumulate.report_type).statement, db.session.bind)
    df = df1.set_index('report_type').add(df2.set_index('report_type'), fill_value=0).reset_index()
    return df.values.tolist()


def get_sum_month():
    month = datetime.date.today().month
    year = datetime.date.today().isocalendar()[0]
    return db.session.query(func.sum(BusinessAccumulate.income).label('total')).filter(BusinessAccumulate.year == year, BusinessAccumulate.month == month).scalar()


def get_total_month():
    # month = datetime.date.today().month
    # year = datetime.date.today().isocalendar()[0]
    # return db.session.query(BusinessAccumulate.report_type, func.sum(BusinessAccumulate.income).label('income')).filter(BusinessAccumulate.year == year, BusinessAccumulate.month == month).group_by(BusinessAccumulate.report_type).all()
    month = datetime.date.today().month
    year = datetime.date.today().isocalendar()[0]
    df1 = pd.read_sql(db.session.query(BusinessToday.report_type.label('report_type'), BusinessToday.income.label('income')).statement, db.session.bind)
    df2 = pd.read_sql(db.session.query(BusinessAccumulate.report_type, func.sum(BusinessAccumulate.income).label('income')).filter(BusinessAccumulate.year == year, BusinessAccumulate.month == month).group_by(BusinessAccumulate.report_type).statement, db.session.bind)
    df = df1.set_index('report_type').add(df2.set_index('report_type'), fill_value=0).reset_index()
    return df.values.tolist()


def update_accumulate_record(_report_type, _income, _update_by, _update_income):
    try:
        # region 記錄更新記錄
        add_record(_report_type, _income, _update_by, _update_income)
        # endregion

        param = _update_income.split('/')
        week = datetime.datetime.strptime(_update_income, "%Y/%m/%d").isocalendar()[1]
        insertdata = {"report_type": _report_type, "year": int(param[0]), "month": int(param[1]), "day": int(param[2]), "week": week, "income": _income, "update_by": _update_by, "updated_at": datetime.datetime.now(), "create_by":_update_by,"created_at": datetime.datetime.now()}
        updatedata = {"income": _income, "update_by": _update_by, "updated_at": datetime.datetime.now()}
        statement = insert(BusinessAccumulate).values(**insertdata).on_duplicate_key_update(**updatedata)
        db.session.execute(statement)
        db.session.commit()
    except Exception as e:
        logger.error('update_last_record.{}'.format(e))
        return 0
    else:
        return 1


class BusinessAccumulate(db.Model):
    """

    """
    __tablename__ = 'business_accumulate'
    report_type = db.Column(db.String(10), primary_key=True)
    income = db.Column(db.Numeric(precision=10, scale=2))
    create_by = db.Column(db.String(50))
    created_at = db.Column(db.DateTime)
    update_by = db.Column(db.String(50))  # 更新者
    updated_at = db.Column(db.DateTime)  # 更新时间
    year = db.Column(db.Integer, primary_key=True)
    week = db.Column(db.Integer)
    month = db.Column(db.Integer, primary_key=True)
    day = db.Column(db.Integer, primary_key=True)
