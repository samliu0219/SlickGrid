var o="assets/logo-mini.1766487426142.svg";export{o as l};
