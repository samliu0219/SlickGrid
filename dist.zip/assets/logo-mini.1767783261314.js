var o="assets/logo-mini.1767783261314.svg";export{o as l};
