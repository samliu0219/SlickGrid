var a="assets/gingkolake.1768110451467.png";export{a as l};
