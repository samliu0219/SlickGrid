var o="assets/logo-mini.1714220072521.svg";export{o as l};
