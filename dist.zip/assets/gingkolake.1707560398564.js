var a="assets/gingkolake.1707560398564.png";export{a as l};
