var o="assets/logo-mini.1716111909447.svg";export{o as l};
