var o="assets/logo-mini.1699189020853.svg";export{o as l};
