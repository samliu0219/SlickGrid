var o="assets/logo-mini.1768124113125.svg";export{o as l};
