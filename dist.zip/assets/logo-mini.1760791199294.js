var o="assets/logo-mini.1760791199294.svg";export{o as l};
