var o="assets/logo-mini.1764982885869.svg";export{o as l};
