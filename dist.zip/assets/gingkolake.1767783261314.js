var a="assets/gingkolake.1767783261314.png";export{a as l};
