var a="assets/gingkolake.1764421122019.png";export{a as l};
