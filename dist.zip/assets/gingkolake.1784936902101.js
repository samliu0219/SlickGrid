var a="assets/gingkolake.1784936902101.png";export{a as l};
