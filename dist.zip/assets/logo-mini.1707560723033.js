var o="assets/logo-mini.1707560723033.svg";export{o as l};
