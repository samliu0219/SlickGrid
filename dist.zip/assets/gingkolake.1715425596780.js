var a="assets/gingkolake.1715425596780.png";export{a as l};
