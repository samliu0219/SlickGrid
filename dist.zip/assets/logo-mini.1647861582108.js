var o="assets/logo-mini.1647861582108.svg";export{o as l};
