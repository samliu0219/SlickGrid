var o="assets/logo-mini.1715425596780.svg";export{o as l};
