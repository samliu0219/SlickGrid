var o="assets/logo-mini.1696920297988.svg";export{o as l};
