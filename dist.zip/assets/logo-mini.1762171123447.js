var o="assets/logo-mini.1762171123447.svg";export{o as l};
