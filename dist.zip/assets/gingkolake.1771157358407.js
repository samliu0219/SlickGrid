var a="assets/gingkolake.1771157358407.png";export{a as l};
