var o="assets/logo-mini.1764421122019.svg";export{o as l};
