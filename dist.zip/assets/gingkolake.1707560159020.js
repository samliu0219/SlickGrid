var a="assets/gingkolake.1707560159020.png";export{a as l};
