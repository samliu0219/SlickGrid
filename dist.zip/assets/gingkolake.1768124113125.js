var a="assets/gingkolake.1768124113125.png";export{a as l};
