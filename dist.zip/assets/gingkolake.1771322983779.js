var a="assets/gingkolake.1771322983779.png";export{a as l};
