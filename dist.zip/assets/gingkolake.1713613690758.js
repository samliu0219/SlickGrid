var a="assets/gingkolake.1713613690759.png";export{a as l};
