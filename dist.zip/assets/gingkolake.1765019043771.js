var a="assets/gingkolake.1765019043771.png";export{a as l};
