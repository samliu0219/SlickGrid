var a="assets/gingkolake.1768102438591.png";export{a as l};
