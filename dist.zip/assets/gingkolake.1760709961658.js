var a="assets/gingkolake.1760709961658.png";export{a as l};
