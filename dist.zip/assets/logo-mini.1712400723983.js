var o="assets/logo-mini.1712400723983.svg";export{o as l};
