var a="assets/gingkolake.1768109914549.png";export{a as l};
