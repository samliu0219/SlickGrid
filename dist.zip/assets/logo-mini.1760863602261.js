var o="assets/logo-mini.1760863602261.svg";export{o as l};
