var o="assets/logo-mini.1716635225161.svg";export{o as l};
