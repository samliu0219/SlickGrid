var o="assets/logo-mini.1765019043771.svg";export{o as l};
