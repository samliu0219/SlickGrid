var o="assets/logo-mini.1707560159020.svg";export{o as l};
