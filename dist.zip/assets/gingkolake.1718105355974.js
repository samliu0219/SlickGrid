var a="assets/gingkolake.1718105355974.png";export{a as l};
