var a="assets/gingkolake.1704458564533.png";export{a as l};
