var o="assets/logo-mini.1784969557863.svg";export{o as l};
