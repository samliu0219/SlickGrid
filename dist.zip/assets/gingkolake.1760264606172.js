var a="assets/gingkolake.1760264606172.png";export{a as l};
