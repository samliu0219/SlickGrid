var o="assets/logo-mini.1766493314947.svg";export{o as l};
