var a="assets/gingkolake.1707560723033.png";export{a as l};
