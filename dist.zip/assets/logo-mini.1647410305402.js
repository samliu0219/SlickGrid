var o="assets/logo-mini.1647410305402.svg";export{o as l};
