var a="assets/gingkolake.1707828556223.png";export{a as l};
