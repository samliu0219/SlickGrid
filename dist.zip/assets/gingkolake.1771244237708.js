var a="assets/gingkolake.1771244237708.png";export{a as l};
