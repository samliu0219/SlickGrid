var a="assets/gingkolake.1760791199294.png";export{a as l};
