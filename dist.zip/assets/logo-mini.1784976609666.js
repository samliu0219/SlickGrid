var o="assets/logo-mini.1784976609666.svg";export{o as l};
