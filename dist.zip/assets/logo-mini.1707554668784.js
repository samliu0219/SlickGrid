var o="assets/logo-mini.1707554668784.svg";export{o as l};
