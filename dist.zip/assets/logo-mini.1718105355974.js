var o="assets/logo-mini.1718105355974.svg";export{o as l};
