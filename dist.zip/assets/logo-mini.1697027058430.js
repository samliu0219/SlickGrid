var o="assets/logo-mini.1697027058430.svg";export{o as l};
