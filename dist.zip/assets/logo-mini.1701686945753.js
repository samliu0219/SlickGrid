var o="assets/logo-mini.1701686945753.svg";export{o as l};
