var o="assets/logo-mini.1706184259514.svg";export{o as l};
