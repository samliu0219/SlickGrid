var o="assets/logo-mini.1707828556223.svg";export{o as l};
