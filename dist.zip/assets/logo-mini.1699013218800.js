var o="assets/logo-mini.1699013218800.svg";export{o as l};
