var o="assets/logo-mini.1714993952153.svg";export{o as l};
