var o="assets/logo-mini.1768110451467.svg";export{o as l};
