var a="assets/gingkolake.1761383347850.png";export{a as l};
