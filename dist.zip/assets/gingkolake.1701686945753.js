var a="assets/gingkolake.1701686945753.png";export{a as l};
