var o="assets/logo-mini.1707560398564.svg";export{o as l};
