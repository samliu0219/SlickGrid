var o="assets/logo-mini.1771244237708.svg";export{o as l};
