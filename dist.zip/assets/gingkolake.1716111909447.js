var a="assets/gingkolake.1716111909447.png";export{a as l};
