var o="assets/logo-mini.1781002753463.svg";export{o as l};
