var a="assets/gingkolake.1701608491913.png";export{a as l};
