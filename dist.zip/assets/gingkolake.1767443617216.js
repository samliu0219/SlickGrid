var a="assets/gingkolake.1767443617216.png";export{a as l};
