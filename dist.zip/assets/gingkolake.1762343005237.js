var a="assets/gingkolake.1762343005237.png";export{a as l};
