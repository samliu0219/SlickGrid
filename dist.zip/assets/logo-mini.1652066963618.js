var o="assets/logo-mini.1652066963618.svg";export{o as l};
