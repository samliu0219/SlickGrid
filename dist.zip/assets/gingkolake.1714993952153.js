var a="assets/gingkolake.1714993952153.png";export{a as l};
