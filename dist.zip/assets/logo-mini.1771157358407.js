var o="assets/logo-mini.1771157358407.svg";export{o as l};
