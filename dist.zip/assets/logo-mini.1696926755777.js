var o="assets/logo-mini.1696926755777.svg";export{o as l};
