var a="assets/gingkolake.1762171123447.png";export{a as l};
