var a="assets/gingkolake.1760179308689.png";export{a as l};
