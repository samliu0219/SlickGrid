var o="assets/logo-mini.1699083558179.svg";export{o as l};
