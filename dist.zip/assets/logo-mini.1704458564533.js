var o="assets/logo-mini.1704458564533.svg";export{o as l};
