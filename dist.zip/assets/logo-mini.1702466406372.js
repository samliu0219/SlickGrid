var o="assets/logo-mini.1702466406372.svg";export{o as l};
