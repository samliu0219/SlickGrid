var a="assets/gingkolake.1706439742264.png";export{a as l};
