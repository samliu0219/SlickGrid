var o="assets/logo-mini.1713613690759.svg";export{o as l};
