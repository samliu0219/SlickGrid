var o="assets/logo-mini.1647396284621.svg";export{o as l};
