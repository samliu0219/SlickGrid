var a="assets/gingkolake.1768110261542.png";export{a as l};
