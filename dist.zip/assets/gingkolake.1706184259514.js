var a="assets/gingkolake.1706184259514.png";export{a as l};
