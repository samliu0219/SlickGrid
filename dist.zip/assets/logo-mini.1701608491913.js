var o="assets/logo-mini.1701608491913.svg";export{o as l};
