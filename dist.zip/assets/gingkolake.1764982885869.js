var a="assets/gingkolake.1764982885869.png";export{a as l};
