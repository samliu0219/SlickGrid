var o="assets/logo-mini.1766921656947.svg";export{o as l};
