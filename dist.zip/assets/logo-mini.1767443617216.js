var o="assets/logo-mini.1767443617216.svg";export{o as l};
