var a="assets/gingkolake.1784976609666.png";export{a as l};
