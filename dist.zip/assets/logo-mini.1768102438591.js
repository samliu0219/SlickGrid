var o="assets/logo-mini.1768102438591.svg";export{o as l};
