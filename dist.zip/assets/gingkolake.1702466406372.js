var a="assets/gingkolake.1702466406372.png";export{a as l};
