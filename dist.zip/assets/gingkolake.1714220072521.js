var a="assets/gingkolake.1714220072521.png";export{a as l};
