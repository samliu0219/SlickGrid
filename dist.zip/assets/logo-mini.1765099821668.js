var o="assets/logo-mini.1765099821668.svg";export{o as l};
