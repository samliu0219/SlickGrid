var o="assets/logo-mini.1699057145699.svg";export{o as l};
