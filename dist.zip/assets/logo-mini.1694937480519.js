var o="assets/logo-mini.1694937480519.svg";export{o as l};
