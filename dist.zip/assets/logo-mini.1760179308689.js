var o="assets/logo-mini.1760179308689.svg";export{o as l};
