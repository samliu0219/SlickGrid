var o="assets/logo-mini.1761383347850.svg";export{o as l};
