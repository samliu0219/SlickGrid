var o="assets/logo-mini.1760709961658.svg";export{o as l};
