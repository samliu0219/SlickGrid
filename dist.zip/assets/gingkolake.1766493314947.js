var a="assets/gingkolake.1766493314947.png";export{a as l};
