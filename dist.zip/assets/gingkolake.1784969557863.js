var a="assets/gingkolake.1784969557863.png";export{a as l};
