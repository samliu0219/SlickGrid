var o="assets/logo-mini.1760264606172.svg";export{o as l};
