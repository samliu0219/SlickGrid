var a="assets/gingkolake.1781002753463.png";export{a as l};
