var o="assets/logo-mini.1647949837363.svg";export{o as l};
