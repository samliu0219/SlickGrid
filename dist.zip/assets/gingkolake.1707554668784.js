var a="assets/gingkolake.1707554668784.png";export{a as l};
