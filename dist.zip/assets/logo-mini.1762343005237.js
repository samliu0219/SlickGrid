var o="assets/logo-mini.1762343005237.svg";export{o as l};
