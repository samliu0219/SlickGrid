var o="assets/logo-mini.1768110261542.svg";export{o as l};
