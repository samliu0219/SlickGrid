var o="assets/logo-mini.1700569198055.svg";export{o as l};
