var a="assets/gingkolake.1765099821668.png";export{a as l};
