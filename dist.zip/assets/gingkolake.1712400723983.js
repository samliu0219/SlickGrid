var a="assets/gingkolake.1712400723983.png";export{a as l};
