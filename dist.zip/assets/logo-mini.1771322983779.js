var o="assets/logo-mini.1771322983779.svg";export{o as l};
