var o="assets/logo-mini.1706439742264.svg";export{o as l};
