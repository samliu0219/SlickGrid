var a="assets/gingkolake.1766921656947.png";export{a as l};
