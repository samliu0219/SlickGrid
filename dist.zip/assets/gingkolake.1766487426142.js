var a="assets/gingkolake.1766487426142.png";export{a as l};
