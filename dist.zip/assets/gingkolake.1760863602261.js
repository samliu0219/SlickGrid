var a="assets/gingkolake.1760863602261.png";export{a as l};
