var o="assets/logo-mini.1784936902101.svg";export{o as l};
