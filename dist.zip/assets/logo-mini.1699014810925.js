var o="assets/logo-mini.1699014810925.svg";export{o as l};
