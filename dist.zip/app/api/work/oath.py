import logging
from flask import Blueprint, request, current_app, session, redirect, url_for
from wechatpy.work import WeChatClient
import functools
from app.utils.core import db
from app.models.sys_user import SysUser

# region 前置区
bp = Blueprint("work/oath", __name__, url_prefix='/')
logger = logging.getLogger(__name__)
# endregion

client = WeChatClient("wwbb2b7bbc151ab86a", "4cvlKdOyBkGTHKwS-RAMw11SyjaNf5zYnvDyLR9l16w")


def oauth(method):
    @functools.wraps(method)
    def warpper(*args, **kwargs):
        code = request.args.get('code', None)
        url = client.oauth.authorize_url(request.url)
        if code:
            try:
                user_info = client.oauth.get_user_info(code)
            except Exception as e:
                logger.info('e=>{}.{}'.format(e.errmsg, e.errcode))
                # 这里需要处理请求里包含的 code 无效的情况
            else:
                session['user_info'] = user_info
        else:
            return redirect(url)
        return method(*args, **kwargs)

    return warpper


@bp.route('/work/oath', methods=["POST", "GET"])
@oauth
def work_oath():
    # {'UserId': 'LiuDaCheng', 'DeviceId': 'c2b4be35-6df6-464f-9d7a-3d1380b6399b', 'errcode': 0, 'errmsg': 'ok'}
    user_info = session.get('user_info')

    # region 在数据表中,检查UserID
    if user_info['errcode'] != 0 or user_info['errmsg'] != 'ok':
        return 'error'
    _user = db.session.query(SysUser).filter(SysUser.work_id == user_info['UserId']).first()
    if not _user or not _user['user_name']:
        return 'error2'
    # endregion

    # logger.info('web.....user_info={}'.format(user_info))

    return redirect(url_for('businessexpress', user_name=_user['user_name'], a=2, b=3))
    # jsonify(data=user_info)
