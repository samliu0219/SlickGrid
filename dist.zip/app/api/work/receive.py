import logging
import json
from flask import Blueprint, request, current_app
from wechatpy.work.crypto import WeChatCrypto
from wechatpy.exceptions import InvalidSignatureException
from wechatpy.work.exceptions import InvalidCorpIdException
from wechatpy.work import parse_message, create_reply
from app.utils.code import ResponseCode
from app.utils.response import ResMsg

# region 前置区
bp = Blueprint("work/receive", __name__, url_prefix='/')
logger = logging.getLogger(__name__)
# endregion


@bp.route('/work/receive', methods=["POST", "GET"])
def work_receive():
    res = ResMsg()
    # region 读取配置
    try:
        token = current_app.config.get("WORK_TOKEN")
        encoding_aes_key = current_app.config.get("WORK_EncodingAESKey")
        corp_id = current_app.config.get("WORK_CORP_ID")
    except Exception as e:
        logger.error('读取配置错误.{}'.format(e))
        res.update(code=ResponseCode.ErrorReadConfig)
    # endregion
    # region 接收参数与判断
    signature = request.args.get("msg_signature", "")
    timestamp = request.args.get("timestamp", "")
    nonce = request.args.get("nonce", "")
    if signature is None or len(signature) == 0:
        res.update(code=ResponseCode.InvalidParameter, msg="signature")
        return res.data
    if timestamp is None or len(timestamp) == 0:
        res.update(code=ResponseCode.InvalidParameter, msg="timestamp")
        return res.data
    if nonce is None or len(nonce) == 0:
        res.update(code=ResponseCode.InvalidParameter, msg="nonce")
        return res.data
    # endregion
    crypto = WeChatCrypto(token, encoding_aes_key, corp_id)
    logger.info('crypto={}'.format(crypto))
    if request.method == "GET":
        echo_str = request.args.get("echostr", "")
        try:
            echo_str = crypto.check_signature(signature, timestamp, nonce, echo_str)
        except InvalidSignatureException:
            res.update(code=ResponseCode.unKnow)
            return res.data
        return echo_str
    else:
        try:
            msg = crypto.decrypt_message(request.data, signature, timestamp, nonce)
        except (InvalidSignatureException, InvalidCorpIdException):
            res.update(code=ResponseCode.unKnow)
            return res.data
        msg = parse_message(msg)
        if msg.type == "text":
            reply = create_reply(msg.content, msg).render()
        else:
            reply = create_reply("Can not handle this for now", msg).render()
        res = crypto.encrypt_message(reply, nonce, timestamp)
        return res
