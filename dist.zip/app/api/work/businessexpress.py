import logging
from flask import Blueprint, request

# region 前置区
bp = Blueprint("work/businessexpress", __name__, url_prefix='/')
logger = logging.getLogger(__name__)


# endregion


@bp.route('/work/businessexpress', methods=["POST", "GET"])
def businessexpress():
    code = request.args.get('code', None)
    logger.info('code={}'.format(code))
    return 'ok'
