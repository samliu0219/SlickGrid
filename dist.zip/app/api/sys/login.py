import json
import logging

from flask import Blueprint, request
from app.models.sys_menu import SysMenu
from app.utils.code import ResponseCode
from app.utils.response import ResMsg
from app.utils.core import db
from app.models.sys_user import auth, update_ip
from app.models.sys_login_record import add_record
from app.models.sys_user_role import get_roles_by_userid
from app.utils.auth import Auth

bp = Blueprint("sys/login", __name__, url_prefix='/')
logger = logging.getLogger(__name__)


@bp.route('/sys/login/login', methods=["POST", "GET"])
def check_password():
    """
    登入流程
    1.空值检查
    2.检验帐密
    2.记录登入IP信息
    :return:
    """

    res = ResMsg()
    try:
        obj = request.get_json(force=True)
        uid = obj.get('uid', None)
        pwd = obj.get('pwd', None)
        # region  1.空值检查
        if not obj or not uid:
            res.update(code=ResponseCode.InvalidParameter)
            return res.data
        if not obj or not pwd:
            res.update(code=ResponseCode.InvalidParameter)
            return res.data
        # endregion
        # region 2.密码验证
        _sysUser = auth(uid, pwd)
        if _sysUser is None:
            res.update(code=ResponseCode.AccountOrPassWordErr)
            return res.data
        # endregion
        # region 3.登入记录
        ip = request.remote_addr
        try:
            add_record(_sysUser.id, ip)
        except Exception as e:
            logger.error('3.登入记录.{}'.format(e))
            res.update(code=ResponseCode.unKnow)
        # endregion
        # region 4.更新用户数据
        try:
            update_ip(_sysUser.id, ip)
        except Exception as e:
            logger.error('4.更新用户数据.{}'.format(e))
            res.update(code=ResponseCode.unKnow)
        # endregion
        _data = {}  # 响应数据结构
        # region 5.生成Token
        try:
            token, refresh_token = Auth.encode_auth_token(user_id=_sysUser.id)
            _data['token'] = token
            _data['refresh_token'] = refresh_token
        except Exception as e:
            logger.error('4.生成Token.{}'.format(e))
            res.update(code=ResponseCode.unKnow)
        # endregion
        # region 6.捞取用户资料,用户性名,角色等
        try:
            _data['userName'] = _sysUser.user_name
            _data['userId'] = _sysUser.account
            _data['photo'] = _sysUser.avatar
            _data['expire_password'] = _sysUser.pwd_updated_at
            _obj = get_roles_by_userid(_sysUser.id)
            _lst = []
            for v in _obj:
                _lst.append(v[0])
            _data['roles'] = _lst
            _data['btns'] = ['btn.add', 'btn.del', 'btn.edit', 'btn.link']
        except Exception as e:
            logger.error('6.捞取用户资料.{}'.format(e))
            res.update(code=ResponseCode.unKnow)
        # endregion
        res.update(code=ResponseCode.Success, data=_data)
    except Exception as e:
        logger.error(e)
        res.update(code=ResponseCode.unKnow)
    return res.data
