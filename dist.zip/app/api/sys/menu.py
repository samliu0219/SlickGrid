import logging
from flask import Blueprint, request
import json
from app.utils.auth import login_required
from app.models.sys_menu import SysMenu
from app.models.sys_role import SysRole
from app.models.sys_role_menu import SysRoleMenu
from app.utils.code import ResponseCode
from app.utils.response import ResMsg
from app.utils.core import db

bp = Blueprint("sys/menu", __name__, url_prefix='/')

logger = logging.getLogger(__name__)


def find_index(_item, itmes):
    """
    递归菜单
    :param _item:
    :param itmes:
    :return:
    """
    for i, it in enumerate(itmes):
        if _item['parent_id'] == it['id']:
            itmes[i]['children'].append(_item)
        else:
            if len(it['children']) > 0:
                find_index(_item, it['children'])


def parse_menu(items, roles):
    """
    将菜单数据转换为接口结构
    :return:
    """
    result = []
    for item in items:
        _result = {'parent_id': item.parent_id, "id": item.id, "path": item.path, "name": item.name, "component": item.component}
        _meta = {"title": item.title, "isLink": item.is_link, "isHide": item.is_hide, "isKeepAlive": item.keep_alive,
                 "isAffix": item.is_fix, "isIframe": item.is_frame, "roles": roles, "icon": item.icon}
        _result["meta"] = _meta
        _result["children"] = []
        if item.parent_id == 0:
            result.append(_result)
        else:
            find_index(_result, result)
    return result


@bp.route('/sys/menu/get_menu', methods=["POST", "GET"])
def get_menu():
    """
    获取菜单
    :return:
    """
    res = ResMsg()
    try:
        obj = request.get_json(force=True)
        role = obj.get('role', None)
        _menus = db.session.query(SysMenu).join(SysRoleMenu, SysRoleMenu.menu_id == SysMenu.id).join(SysRole, SysRole.id == SysRoleMenu.role_id).filter(SysRole.role_key.in_(role)).order_by(SysMenu.order_num.asc()).all()
        _data = parse_menu(_menus, role)
        res.update(code=ResponseCode.Success, data=_data)
    except Exception as e:
        logger.error('获取菜单数据.{}'.format(e))
        res.update(code=ResponseCode.unKnow)
    return res.data
