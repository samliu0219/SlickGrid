from app.utils.core import db


class SysRoleMenu(db.Model):
    """
    角色菜单关系表
    """
    __tablename__ = 'sys_role_menu'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # ID
    role_id = db.Column(db.Integer, db.ForeignKey('sys_role.id'))  # 角色ID
    menu_id = db.Column(db.Integer, db.ForeignKey('sys_menu.id'))  # 菜单ID
