import logging
import jwt
from app.utils.core import db
from datetime import datetime


key = "2JNf4Lirfonoz$qjo9LANgFVUwua@sdko%uZYHRs9NCzyz7DVM"
logger = logging.getLogger(__name__)


def generate_password(uid, pwd):
    """
    生成加密密码
    :return:
    """
    algorithm = 'HS256'
    now = datetime.strptime('22.1.2020 10:38:42,76', '%d.%m.%Y %H:%M:%S,%f').timestamp() * 1000
    exp_datetime = datetime.strptime('20.12.2222 09:48:47,26', '%d.%m.%Y %H:%M:%S,%f').timestamp() * 1000
    access_payload = {
        'exp': exp_datetime,
        'flag': 1,  # 标识是否为一次性，0是，1不是
        'iat': now,  # 开始时间
        'iss': pwd,  # 签名
        'user_name': uid  # 自定义部分
    }
    return jwt.encode(access_payload, key, algorithm=algorithm)


def auth(uid, pwd):
    """
    检验账号密码
    :param uid:帐号
    :param pwd: 密码
    :return: SysUser
    """
    _cpwd = generate_password(uid, pwd)
    _user = db.session.query(SysUser).filter(SysUser.account == uid, SysUser.password == _cpwd).first()
    return _user


def update_ip(uid, ip):
    """

    :param uid:
    :param ip:
    :return:
    """
    user = db.session.query(SysUser).filter(SysUser.id == uid).first()
    user.login_ip = ip
    user.login_date = datetime.now()
    db.session.add(user)
    db.session.commit()


class SysUser(db.Model):
    """
    用户信息表
    """
    __tablename__ = 'sys_user'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # 用户ID
    account = db.Column(db.String(50))  # 登录账号
    user_name = db.Column(db.String(200))  # 用户昵称
    user_type = db.Column(db.String(50))  # 用户类型
    email = db.Column(db.String(50))  # 用户邮箱
    phone = db.Column(db.String(50))  # 手机号
    sex = db.Column(db.Integer)  # 用户性别
    avatar = db.Column(db.String(200))  # 头像路径
    password = db.Column(db.String(512))  # 密码
    status = db.Column(db.Integer)  # 帐号状态
    login_ip = db.Column(db.String(50))  # 最后登陆IP
    login_date = db.Column(db.DateTime)  # 最后登陆时间
    create_by = db.Column(db.String(50))  # 创建者
    created_at = db.Column(db.DateTime, default=db.func.utcnow())  # 创建时间
    update_by = db.Column(db.String(50))  # 更新者
    updated_at = db.Column(db.DateTime, default=db.func.utcnow())  # 更新时间
    deleted_at = db.Column(db.DateTime, default=db.func.utcnow())  # 删除时间
    remark = db.Column(db.String(50))  # 备注
    pwd_updated_at = db.Column(db.DateTime)  # 密码更新日
