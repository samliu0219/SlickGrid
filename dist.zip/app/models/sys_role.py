from app.utils.core import db


class SysRole(db.Model):
    """
    角色表
    """
    __tablename__ = 'sys_role'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # 菜单ID
    role_name = db.Column(db.String(50), nullable=False)  # 角色名称
    role_key = db.Column(db.String(50), nullable=False)  # 角色权限字符串
    role_sort = db.Column(db.Integer, default=0, nullable=False)  # 显示顺序
    data_scope = db.Column(db.String(50), nullable=False)  # 数据范围
    status = db.Column(db.Integer, default=0, nullable=False)  # 角色状态
    create_by = db.Column(db.String(200), nullable=False)  # 创建者
    created_at = db.Column(db.DateTime, nullable=False, default=db.func.utcnow())  # 创建时间
    update_by = db.Column(db.String(200), nullable=False)  # 更新者
    updated_at = db.Column(db.DateTime, nullable=False, default=db.func.utcnow(), onupdate=db.func.utcnow())  # 更新时间
    remark = db.Column(db.String(200), nullable=False)  # 备注
