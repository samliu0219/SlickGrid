from app.utils.core import db


class SysMenu(db.Model):
    """
    菜单信息表
    """
    __tablename__ = 'sys_menu'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # 菜单ID
    parent_id = db.Column(db.Integer, default=0, nullable=False)  # 父菜单ID
    title = db.Column(db.String(100), nullable=False)  # 菜单名称
    path = db.Column(db.String(200), nullable=False)  # 路由路径
    name = db.Column(db.String(200), nullable=False)  # 路由名称
    component = db.Column(db.String(200), nullable=False)  # 路由组件
    redirect = db.Column(db.String(200), nullable=False)  # 路由重定向
    order_num = db.Column(db.Integer, default=0, nullable=False)  # 显示顺序
    is_link = db.Column(db.String(200), nullable=False)  # 外链地址
    menu_type = db.Column(db.Integer, default=0, nullable=False)  # 菜单类型,1,目录 2,菜单 3,按钮
    is_hide = db.Column(db.Boolean, default=False, nullable=False)  # 菜单状态,1显示 2隐藏
    keep_alive = db.Column(db.Boolean, default=True, nullable=False)  # 是否缓存
    is_fix = db.Column(db.Boolean, default=True, nullable=False)  # 菜单是否固定
    icon = db.Column(db.String(200), nullable=False)  # 菜单图标
    is_frame = db.Column(db.Boolean, default=False, nullable=False)  # 是否内嵌
    create_by = db.Column(db.String(200), nullable=False)  # 创建者
    created_at = db.Column(db.DateTime, nullable=False, default=db.func.utcnow())  # 创建时间
    update_by = db.Column(db.String(200), nullable=False)  # 更新者
    updated_at = db.Column(db.DateTime, nullable=False, default=db.func.utcnow(), onupdate=db.func.utcnow())  # 更新时间
    remark = db.Column(db.String(200), nullable=False)  # 备注
