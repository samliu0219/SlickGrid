# -*- coding: utf-8 -*-


from wechatpy.client.api.card import WeChatCard  # NOQA
from wechatpy.client.api.customservice import WeChatCustomService  # NOQA
from wechatpy.client.api.datacube import WeChatDataCube  # NOQA
from wechatpy.client.api.device import WeChatDevice  # NOQA
from wechatpy.client.api.group import WeChatGroup  # NOQA
from wechatpy.client.api.invoice import WeChatInvoice  # NOQA
from wechatpy.client.api.jsapi import WeChatJSAPI  # NOQA
from wechatpy.client.api.material import WeChatMaterial  # NOQA
from wechatpy.client.api.media import WeChatMedia  # NOQA
from wechatpy.client.api.menu import WeChatMenu  # NOQA
from wechatpy.client.api.merchant import WeChatMerchant  # NOQA
from wechatpy.client.api.message import WeChatMessage  # NOQA
from wechatpy.client.api.misc import WeChatMisc  # NOQA
from wechatpy.client.api.poi import WeChatPoi  # NOQA
from wechatpy.client.api.qrcode import WeChatQRCode  # NOQA
from wechatpy.client.api.scan import WeChatScan  # NOQA
from wechatpy.client.api.semantic import WeChatSemantic  # NOQA
from wechatpy.client.api.shakearound import WeChatShakeAround  # NOQA
from wechatpy.client.api.tag import WeChatTag  # NOQA
from wechatpy.client.api.template import WeChatTemplate  # NOQA
from wechatpy.client.api.user import WeChatUser  # NOQA
from wechatpy.client.api.wifi import WeChatWiFi  # NOQA
from wechatpy.client.api.wxa import WeChatWxa  # NOQA
from wechatpy.client.api.marketing import WeChatMarketing  # NOQA
from wechatpy.client.api.cloud import WeChatCloud  # NOQA
