# -*- coding: utf-8 -*-


from wechatpy.work.client.api.agent import WeChatAgent  # NOQA
from wechatpy.work.client.api.appchat import WeChatAppChat  # NOQA
from wechatpy.work.client.api.batch import WeChatBatch  # NOQA
from wechatpy.work.client.api.calendar import WeChatCalendar  # NOQA
from wechatpy.work.client.api.department import WeChatDepartment  # NOQA
from wechatpy.work.client.api.external_contact import WeChatExternalContact  # NOQA
from wechatpy.work.client.api.external_contact_group_chat import WeChatExternalContactGroupChat
from wechatpy.work.client.api.invoice import WeChatInvoice  # NOQA
from wechatpy.work.client.api.jsapi import WeChatJSAPI  # NOQA
from wechatpy.work.client.api.media import WeChatMedia  # NOQA
from wechatpy.work.client.api.menu import WeChatMenu  # NOQA
from wechatpy.work.client.api.message import WeChatMessage  # NOQA
from wechatpy.work.client.api.misc import WeChatMisc  # NOQA
from wechatpy.work.client.api.oa import WeChatOA  # NOQA
from wechatpy.work.client.api.oauth import WeChatOAuth  # NOQA
from wechatpy.work.client.api.schedule import WeChatSchedule  # NOQA
from wechatpy.work.client.api.service import WeChatService  # NOQA
from wechatpy.work.client.api.tag import WeChatTag  # NOQA
from wechatpy.work.client.api.user import WeChatUser  # NOQA
