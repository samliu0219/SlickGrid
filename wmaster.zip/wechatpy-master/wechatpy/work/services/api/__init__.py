from wechatpy.work.services.api.auth import WeChatAuth  # NOQA
from wechatpy.work.services.api.miniprogram import WeChatMiniProgram  # NOQA
