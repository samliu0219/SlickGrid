支持项目开发
===============

wechatpy 是采用 MIT 许可的开源项目，使用完全免费。 但为了项目能够健康持续的发展下去，我们期望获得相应的资金支持。 你可以通过下列的方法来赞助我们的开发。

一次性赞助
-----------

你可以通过以下任意一种方式赞助:

1. 微信支付

.. image:: _static/images/wechat.jpg

2. 支付宝

.. image:: _static/images/alipay.jpg

周期性赞助
-------------

`Open Collective <https://opencollective.com/wechatpy>`_