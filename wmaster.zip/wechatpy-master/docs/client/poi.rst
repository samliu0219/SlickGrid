微信门店接口
==================

.. module:: wechatpy.client.api

.. autoclass:: WeChatPoi
   :members:
   :inherited-members:
