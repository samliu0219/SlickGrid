云开发接口
===================

.. module:: wechatpy.client.api

.. autoclass:: WeChatCloud
   :members:
   :inherited-members:
