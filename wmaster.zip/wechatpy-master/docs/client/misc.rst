工具类接口
================

.. module:: wechatpy.client.api

.. autoclass:: WeChatMisc
   :members:
   :inherited-members:
