用户标签接口
===================

.. module:: wechatpy.client.api

.. autoclass:: WeChatTag
   :members:
   :inherited-members:
