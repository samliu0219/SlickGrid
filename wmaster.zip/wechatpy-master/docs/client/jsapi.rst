JS-SDK 接口
=================

.. module:: wechatpy.client.api

.. autoclass:: WeChatJSAPI
   :members:
   :inherited-members:
