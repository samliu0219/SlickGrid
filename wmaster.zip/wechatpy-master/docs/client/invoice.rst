发票接口
==========

.. module:: wechatpy.client.api

.. autoclass:: WeChatInvoice
   :members:
   :inherited-members:
