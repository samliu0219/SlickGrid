二维码接口
==============

.. module:: wechatpy.client.api

.. autoclass:: WeChatQRCode
   :members:
   :inherited-members:
