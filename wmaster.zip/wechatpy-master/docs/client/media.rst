媒体文件接口
===================

.. module:: wechatpy.client.api

.. autoclass:: WeChatMedia
   :members:
   :inherited-members:
