摇一摇周边接口
=================

.. module:: wechatpy.client.api

.. autoclass:: WeChatShakeAround
   :members:
   :inherited-members:
