微信小店接口
==================

.. module:: wechatpy.client.api

.. autoclass:: WeChatMerchant
   :members:
   :inherited-members:
