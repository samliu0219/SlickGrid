模板消息相关接口
=====================

.. module:: wechatpy.client.api

.. autoclass:: WeChatTemplate
   :members:
   :inherited-members:
