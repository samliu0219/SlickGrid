客服消息接口
===================

.. module:: wechatpy.client.api

.. autoclass:: WeChatCustomService
   :members:
   :inherited-members:
