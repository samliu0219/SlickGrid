微信扫一扫接口
====================

.. module:: wechatpy.client.api

.. autoclass:: WeChatScan
   :members:
   :inherited-members:
