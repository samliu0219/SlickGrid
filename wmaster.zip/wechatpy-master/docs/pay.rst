微信支付接口
===========================================

WeChatPay
----------------

.. module:: wechatpy.pay

.. autoclass:: WeChatPay
   :members:
   :inherited-members:


.. module:: wechatpy.pay.api

现金红包接口
---------------------------------

.. autoclass:: WeChatRedpack
   :members:
   :inherited-members:


企业付款接口
---------------------------------

.. autoclass:: WeChatTransfer
   :members:
   :inherited-members:


代金券接口
---------------------------------

.. autoclass:: WeChatCoupon
   :members:
   :inherited-members:


订单接口
---------------------------------

.. autoclass:: WeChatOrder
   :members:
   :inherited-members:


退款接口
-------------------------

.. autoclass:: WeChatRefund
   :members:
   :inherited-members:


工具类接口
---------------------------------

.. autoclass:: WeChatTools
   :members:
   :inherited-members:


公众号网页 JS 支付接口
-------------------------------------

.. autoclass:: WeChatJSAPI
   :members:
   :inherited-members:


代扣接口
-------------------------------------

.. autoclass:: WeChatWithhold
   :members:
   :inherited-members:
